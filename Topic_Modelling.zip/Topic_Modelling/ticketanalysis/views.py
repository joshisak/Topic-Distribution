from django.shortcuts import render, render_to_response
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import os
from ticketanalysis import analysis
import pandas as pd
import requests
from django.shortcuts import render_to_response
import simplejson as json
import xlsxwriter

# Create your views here.
path = os.getcwd()
def index(request):
    
    if request.method == 'POST' and 'upload' in request.POST:
        myfile = request.FILES['myfile']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        return render(request,'index.html',{'uploaded_file_url': uploaded_file_url})

    return render(request,'index.html')

def result(request):
    topic = 10
    word = 5
    ngram = 2
   
    #loading(request)
    import os
    #get cookies
    #myfile =request.COOKIES.get('myfile')
    filepath = os.path.join(path, "Sample Tickets.xlsx")
    #topic = request.COOKIES.get('topic')
    #word =request.COOKIES.get('word')
    #ngram =request.COOKIES.get('ngram')
    
    #call the ticket analysis function
    data_filter, text = analysis.data_filter(filepath)
    dicts, topic_assigned, count_vector, data = analysis.lda_process(data_filter, int(topic), int(word), text)
    result, cloud = analysis.ngram_process(data,int(ngram),text)
    
    #create file for final output
    writer = pd.ExcelWriter('E:/Sakshi/Topic_Modelling/ticketanalysis/static/Result.xlsx')
    data_filter.to_excel(writer,'Dataset')
    dicts.to_excel(writer,'Topic_Modelling')
    topic_assigned.to_excel(writer,'Topic_assigned')
    result.to_excel(writer,'Ngram')
    writer.save()
    
    import openpyxl as xl
    path2 = 'E://Sakshi//Topic_Modelling//ticketanalysis//static//Result.xlsx'

    wb = xl.load_workbook(filename=path2)
    ws1 = wb.create_sheet('Pie_Chart')
    ws2 = wb.create_sheet('Word_Cloud')
    img1 = xl.drawing.image.Image('E:/Sakshi/Topic_Modelling/ticketanalysis/static/pie-chart.png')
    img2 = xl.drawing.image.Image('E:/Sakshi/Topic_Modelling/ticketanalysis/static/word-cloud.png')
    img1.anchor = 'A1'
    img2.anchor = 'A1'
    ws1.add_image(img1)
    ws2.add_image(img2)
    wb.save(path2)

    if request.method == 'POST' and 'back' in request.POST:
        import os
        myfile =request.COOKIES.get('myfile')
        filepath = os.path.join(path, myfile)
        os.remove(filepath)

    file = 'Result.xlsx'
    return render(request,'result.html', {'ngram': ngram, 'file':file}) # 'words':data_word, 'topic' : data_topic,
                        

def loading(request):

    return (request,'loading.html')
