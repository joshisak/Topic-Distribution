import pandas as pd
import numpy as np
import gensim
from nltk.stem import WordNetLemmatizer
from nltk.stem.porter import *
import numpy as np
np.random.seed(2018)
import nltk
from nltk import ngrams
from nltk.corpus import stopwords
import re
import string
from gensim import corpora
import collections

def clean(doc):
    stop = set(stopwords.words('english'))
    exclude = set(string.punctuation) 
    lemma = WordNetLemmatizer()
    
    stop_free = " ".join([i for i in doc.lower().split() if i not in stop])
    num_free = re.sub('[^a-z ]','',str(stop_free))
    punc_free = ''.join(ch for ch in num_free if ch not in exclude)
    normalized = " ".join(lemma.lemmatize(word) for word in punc_free.split())
    short_word = ' '.join(word for word in normalized.split() if len(word)>3)
    long_word = ' '.join(word for word in short_word.split() if len(word)<10)
    return long_word

def data_filter(filepath):
    data = pd.read_excel(filepath)
    data = data[pd.notnull(data['Incident ID'])]
    #data.dropna(subset=["Incident ID"], inplace = True)  ##data
    #data.dropna(subset=["Number"], inplace = True)  ##data_CCEP
    #data = data.replace('', np.nan, regex=True)
    data['data'] = data['Summary'].apply(str) +' '+data['Description'].apply(str)  ##data
    #data['data'] = data['Short Description'].apply(str)    ##data_CCEP
    
    text = [clean(doc) for doc in data.data]    
    #text = []
    #for row in text_doc:
    #    if row =='':
    #        row = "None"
    #    text.append(row)
    data.data = text
    return data, text

    #lda
def lda_process(data, topic, word, text):
    doc_clean = [clean(doc).split() for doc in data.data] 
    dictionary = corpora.Dictionary(doc_clean)
    doc_term_matrix = [dictionary.doc2bow(doc) for doc in doc_clean]

    Lda = gensim.models.ldamodel.LdaModel
    ldamodel = Lda(doc_term_matrix, 
                   num_topics=topic, 
                   id2word = dictionary, 
                   iterations=100,
                   per_word_topics=True)
    topics = ldamodel.print_topics(num_topics=topic, num_words=word)

    topic_list =[]
    topic_weight =[]
    topics_weight =[]
    for row in topics:
        topic_list.append(str(row).split('+'))
    for row in topic_list:
        topic_weight.append(re.sub('[^A-Za-z0-9.,''* ]', ' ', str(row)))
    for row in topic_weight:
        topics_weight.append(str(row).split(','))

    dicts = pd.DataFrame(topics_weight)
    dicts = dicts.rename(columns={0: "index"})
    dicts = dicts.drop(['index'], axis=1)

    i = 1
    for col_name in dicts.columns: 
        col_name = 'word'+'_{}'.format(i)
        dicts = dicts.rename(columns={i: col_name})
        i = i + 1

    j=1
    k=1
    for col_name in dicts.columns:
        temp=[]
        for i in range(0,topic):
            temp.append(str(dicts[col_name][i]).split("* ")[0])
            dicts[col_name][i] = str(dicts[col_name][i]).split("* ")[1]
        name = 'score'+'_{}'.format(j)
        j=j+1
        dicts.insert(k,name,temp)
        k = k+2

    ###PLOT TOPIC WORDCLOUD

    text = str(text)
    empty = text.count('')
    corpus = [dictionary.doc2bow(text) for text in doc_clean]

    vector = []
    for row in corpus:
        vector.append(ldamodel[row])

    rows = []
    for row in vector:
        topic_v = []
        rows.append(row[0])
    topic_vector = []
    for row in rows:
        topic_v = []
        for item in row:
            topic_v.append(item[1])
        topic_vector.append(topic_v)
    
    vector_df = pd.DataFrame(topic_vector)
    i = 0
    for col_name in vector_df.columns: 
        col_name = 'topic'+'_{}'.format(i+1) + '_weight'
        vector_df = vector_df.rename(columns={i: col_name})
        i = i + 1

    data = pd.concat([data, vector_df], axis=1, sort=False)

    max_array = []
    for row in rows:
        x = -1
        for value in row:
            if x<value[1]:
                x=value[1]
                y=value[0]
        max_array.append((y,x))
    max_array = pd.DataFrame(max_array)
    max_array = max_array.rename(columns={0: "Topic_Assigned", 1: "Weight"})
    data = pd.concat([data, max_array], axis=1, sort=False)
    topic_assigned = data.drop(["data"],axis = 1)
    
    count=collections.Counter(max_array.Topic_Assigned)
    count_topic = []
    index = []
    index_str = []
    for x in count:
        index.append(x+1)
        count_topic.append(count[x])
    index = pd.DataFrame(index)
    index = index.rename(columns={0: "Topic_Number"})
    count_topic = pd.DataFrame(count_topic)
    count_topic = count_topic.rename(columns={0: "Number_of_tickets"})
    count_vector = pd.concat([index, count_topic], axis=1, sort=False)
    count_vector = count_vector.sort_values(by=['Topic_Number'])
    count_vector = count_vector.reset_index()
    count_vector = count_vector.drop(["index"], axis=1)
    count_vector['Number_of_tickets'][0] = count_vector['Number_of_tickets'][0]
    count_vector = count_vector.sort_values(by=['Number_of_tickets'],ascending =False)

    import matplotlib.pyplot as plt
 
    labels = count_vector.Topic_Number
    sizes = count_vector.Number_of_tickets
    # Plot
    fig1, ax1 = plt.subplots()
    ax1.pie(sizes, labels=labels, autopct='%1.1f%%',
         startangle=90)
    ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
    
    plt.tight_layout()
    plt.savefig('E:/Sakshi/Topic_Modelling/ticketanalysis/static/pie-chart.png')
    
    return dicts, topic_assigned, count_vector, data

def ngram_process(data,ngram,text):
    import matplotlib.pyplot as plt
    n=ngram
    topic_weight = re.sub('[^a-z ]', '', str(text))
    from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator
    # lower max_font_size, change the maximum number of word and lighten the background:
    wordcloud = WordCloud(max_font_size=50, max_words=100, background_color="white").generate(topic_weight)
    plt.figure()
    plt.imshow(wordcloud, interpolation="bilinear")
    plt.axis("off")
    plt.savefig('E:/Sakshi/Topic_Modelling/ticketanalysis/static/word-cloud.png')

    Ngrams = ngrams(topic_weight.split(), n)
    fdist = nltk.FreqDist(Ngrams)
    ngram_list = []
    freq = []
    for k,v in fdist.items():
        ngram_list.append(k)
        freq.append(v)
    ngram_list = pd.DataFrame(ngram_list)
    freq = pd.DataFrame(freq)
    freq = freq.rename(columns={0: "frequency"})
    Ngram = pd.concat([ngram_list, freq], axis=1, sort=False)
    result = Ngram.sort_values(by=['frequency'], ascending=False)

    i = 0
    for col_name in result.columns: 
        col_name = 'word'+'_{}'.format(i+1)
        result = result.rename(columns={i: col_name})
        i = i + 1
    result_new = result.drop(['frequency'], axis =1)
    s = []
    for col_name in result_new.columns:
        s.append(col_name )
    df = []
    df = result_new[s].apply(lambda x: ' '.join(x), axis=1)
    df = pd.DataFrame(df)
    df = df.rename(columns={0: "word"})
    count = result['frequency']
    cloud = pd.concat([df, count], axis=1)

    ###PLOT NGRAM WORDCLOUD
    return result, cloud