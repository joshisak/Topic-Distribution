from django.apps import AppConfig


class TicketanalysisConfig(AppConfig):
    name = 'ticketanalysis'
